jQuery(document).ready(function() {
	alert('options');
});